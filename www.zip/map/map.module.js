(function() {
    'use strict';

    angular.module('ariAgroApp.map', [

    ]);
})();