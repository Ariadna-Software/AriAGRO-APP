(function() {
    'use strict';

    angular.module('ariAgroApp.config', [

    ]);
})();