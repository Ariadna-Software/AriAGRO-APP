(function() {

    'use strict';

    angular.module('ariAgroApp.core', [
        'blocks.router'
    ]);
})();
