(function() {
    'use strict';

    angular.module('ariAgroApp.inicio', [

    ]);
})();