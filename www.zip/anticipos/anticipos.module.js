(function() {
    'use strict';

    angular.module('ariAgroApp.anticipos', [

    ]);
})();