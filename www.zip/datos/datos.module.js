(function() {
    'use strict';

    angular.module('ariAgroApp.datos', [

    ]);
})();